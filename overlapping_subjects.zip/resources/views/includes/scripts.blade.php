<script src="{{ asset('node_modules/jquery/dist/jquery.min.js') }}"></script>
<script src="{{ asset('node_modules/popper.js/dist/umd/popper.min.js') }}"></script>
<script src="{{ asset('node_modules/bootstrap/dist/js/bootstrap.min.js') }}"></script>
<script src="{{ asset('node_modules/perfect-scrollbar/dist/js/perfect-scrollbar.jquery.min.js') }}"></script>
<!-- endinject -->
<!-- Plugin js for this page-->
<script src="{{ asset('bower_components/chartist/dist/chartist.min.js') }}"></script>
<script src="{{ asset('node_modules/flot/jquery.flot.js') }}"></script>
<script src="{{ asset('node_modules/flot/jquery.flot.resize.js') }}"></script>
<script src="{{ asset('node_modules/flot/jquery.flot.categories.js') }}"></script>
<script src="{{ asset('node_modules/flot/jquery.flot.pie.js') }}"></script>
<script src="{{ asset('node_modules/rickshaw/vendor/d3.v3.js') }}"></script>
<script src="{{ asset('node_modules/rickshaw/rickshaw.min.js') }}"></script>
<script src="{{ asset('node_modules/chartist-plugin-legend/chartist-plugin-legend.js') }}"></script>
<script src="{{ asset('node_modules/chart.js/dist/Chart.min.js') }}"></script>
<script src="{{ asset('node_modules/jquery-sparkline/jquery.sparkline.min.js') }}"></script>
<!-- End plugin js for this page-->
<!-- inject:js -->
<script src="{{ asset('js/off-canvas.js') }}"></script>
<script src="{{ asset('js/hoverable-collapse.js') }}"></script>
<script src="{{ asset('js/misc.js') }}"></script>
<script src="{{ asset('js/settings.js') }}"></script>
<!-- endinject -->
<!-- Custom js for this page-->
<script src="{{ asset('js/dashboard_1.js') }}"></script>