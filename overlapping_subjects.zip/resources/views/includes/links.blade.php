<!-- plugins:css -->
<link rel="stylesheet" href="{{ asset('/node_modules/mdi/css/materialdesignicons.min.css') }}">
<link rel="stylesheet" href="{{ asset('/node_modules/perfect-scrollbar/dist/css/perfect-scrollbar.min.css') }}">
<!-- endinject -->
<!-- plugin css for this page -->
<link rel="stylesheet" href="{{ asset('/node_modules/rickshaw/rickshaw.min.css') }}" />
<link rel="stylesheet" href="{{ asset('/bower_components/chartist/dist/chartist.min.css') }}" />
<!-- End plugin css for this page -->
<!-- inject:css -->
<link rel="stylesheet" href="{{ asset('/css/style.css') }}">
<!-- endinject -->
<link rel="shortcut icon" href="{{ asset('/images/favicon.html') }}" />

<!-- Icon fonts -->
<link rel="stylesheet" href="{{ asset('/fonts/fontawesome.css') }}">
<link rel="stylesheet" href="{{ asset('/fonts/ionicons.css') }}">
<link rel="stylesheet" href="{{ asset('/fonts/linearicons.css') }}">
<link rel="stylesheet" href="{{ asset('/fonts/open-iconic.css') }}">
<link rel="stylesheet" href="{{ asset('/fonts/pe-icon-7-stroke.css') }}">
<link rel="stylesheet" href="{{ asset('/fonts/feather.css') }}">
